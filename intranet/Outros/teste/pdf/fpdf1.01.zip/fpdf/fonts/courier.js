xfpdf_charwidths["courier"]=new Array()
for(xi=0;xi<=255;xi++)xfpdf_charwidths["courier"][lib.chr(xi)]=600;
xfpdf_charwidths["courierB"]=xfpdf_charwidths["courier"];
xfpdf_charwidths["courierI"]=xfpdf_charwidths["courier"];
xfpdf_charwidths["courierBI"]=xfpdf_charwidths["courier"];
