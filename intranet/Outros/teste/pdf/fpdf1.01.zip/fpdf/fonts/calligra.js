xtype='TrueType';
xname='Calligrapher-Regular';
xdesc=lib.newArray('Ascent',899,'Descent',-234,'CapHeight',731,'Flags',32,'FontBBox','[-50 -234 1328 899]','ItalicAngle',0.0,'StemV',70,'MissingWidth',800);
xup=-200;
xut=20;
xcw=lib.newArray(
	lib.chr(0),800,lib.chr(1),800,lib.chr(2),800,lib.chr(3),800,lib.chr(4),800,lib.chr(5),800,lib.chr(6),800,lib.chr(7),800,lib.chr(8),800,lib.chr(9),800,lib.chr(10),800,lib.chr(11),800,lib.chr(12),800,lib.chr(13),800,lib.chr(14),800,lib.chr(15),800,lib.chr(16),800,lib.chr(17),800,lib.chr(18),800,lib.chr(19),800,lib.chr(20),800,lib.chr(21),800,
	lib.chr(22),800,lib.chr(23),800,lib.chr(24),800,lib.chr(25),800,lib.chr(26),800,lib.chr(27),800,lib.chr(28),800,lib.chr(29),800,lib.chr(30),800,lib.chr(31),800,' ',282,'!',324,'"',405,'#',584,'$',632,'%',980,'&',776,'\'',259,'(',299,')',299,'*',377,'+',600,
	',',259,'-',432,'.',254,'/',597,'0',529,'1',298,'2',451,'3',359,'4',525,'5',423,'6',464,'7',417,'8',457,'9',479,':',275,';',282,'<',600,'=',600,'>',600,'?',501,'@',800,'A',743,
	'B',636,'C',598,'D',712,'E',608,'F',562,'G',680,'H',756,'I',308,'J',314,'K',676,'L',552,'M',1041,'N',817,'O',729,'P',569,'Q',698,'R',674,'S',618,'T',673,'U',805,'V',753,'W',1238,
	'X',716,'Y',754,'Z',599,'[',315,'\\',463,']',315,'^',600,'_',547,'`',278,'a',581,'b',564,'c',440,'d',571,'e',450,'f',347,'g',628,'h',611,'i',283,'j',283,'k',560,'l',252,'m',976,
	'n',595,'o',508,'p',549,'q',540,'r',395,'s',441,'t',307,'u',614,'v',556,'w',915,'x',559,'y',597,'z',452,'{',315,'|',222,'}',315,'~',600,lib.chr(127),800,lib.chr(128),800,lib.chr(129),800,lib.chr(130),0,lib.chr(131),0,
	lib.chr(132),0,lib.chr(133),780,lib.chr(134),0,lib.chr(135),0,lib.chr(136),278,lib.chr(137),0,lib.chr(138),0,lib.chr(139),0,lib.chr(140),1064,lib.chr(141),800,lib.chr(142),800,lib.chr(143),800,lib.chr(144),800,lib.chr(145),259,lib.chr(146),259,lib.chr(147),470,lib.chr(148),470,lib.chr(149),500,lib.chr(150),300,lib.chr(151),600,lib.chr(152),278,lib.chr(153),990,
	lib.chr(154),0,lib.chr(155),0,lib.chr(156),790,lib.chr(157),800,lib.chr(158),800,lib.chr(159),754,lib.chr(160),282,lib.chr(161),324,lib.chr(162),450,lib.chr(163),640,lib.chr(164),518,lib.chr(165),603,lib.chr(166),0,lib.chr(167),519,lib.chr(168),254,lib.chr(169),800,lib.chr(170),349,lib.chr(171),0,lib.chr(172),0,lib.chr(173),432,lib.chr(174),800,lib.chr(175),278,
	lib.chr(176),0,lib.chr(177),0,lib.chr(178),0,lib.chr(179),0,lib.chr(180),278,lib.chr(181),614,lib.chr(182),0,lib.chr(183),254,lib.chr(184),278,lib.chr(185),0,lib.chr(186),305,lib.chr(187),0,lib.chr(188),0,lib.chr(189),0,lib.chr(190),0,lib.chr(191),501,lib.chr(192),743,lib.chr(193),743,lib.chr(194),743,lib.chr(195),743,lib.chr(196),743,lib.chr(197),743,
	lib.chr(198),1060,lib.chr(199),598,lib.chr(200),608,lib.chr(201),608,lib.chr(202),608,lib.chr(203),608,lib.chr(204),308,lib.chr(205),308,lib.chr(206),308,lib.chr(207),308,lib.chr(208),0,lib.chr(209),817,lib.chr(210),729,lib.chr(211),729,lib.chr(212),729,lib.chr(213),729,lib.chr(214),729,lib.chr(215),0,lib.chr(216),729,lib.chr(217),805,lib.chr(218),805,lib.chr(219),805,
	lib.chr(220),805,lib.chr(221),0,lib.chr(222),0,lib.chr(223),688,lib.chr(224),581,lib.chr(225),581,lib.chr(226),581,lib.chr(227),581,lib.chr(228),581,lib.chr(229),581,lib.chr(230),792,lib.chr(231),440,lib.chr(232),450,lib.chr(233),450,lib.chr(234),450,lib.chr(235),450,lib.chr(236),283,lib.chr(237),283,lib.chr(238),283,lib.chr(239),283,lib.chr(240),800,lib.chr(241),595,
	lib.chr(242),508,lib.chr(243),508,lib.chr(244),508,lib.chr(245),508,lib.chr(246),508,lib.chr(247),0,lib.chr(248),508,lib.chr(249),614,lib.chr(250),614,lib.chr(251),614,lib.chr(252),614,lib.chr(253),0,lib.chr(254),0,lib.chr(255),597);
xenc='cp1252';
xdiff='';
xfile='calligra.ttf';
xoriginalsize=40120;

